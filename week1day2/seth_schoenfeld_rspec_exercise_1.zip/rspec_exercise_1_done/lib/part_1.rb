def average(num1, num2)
   sum = num1 + num2
   avg = sum / 2.0
   avg
end

def average_array(array)
  len = array.length
  sum = array.inject{|acc,idx| acc + idx}
  sum / len.to_f
end

def repeat(str,num)
  repeated = ""
  num.times{|n| repeated << str}
  repeated
end

def yell(str)
  yelled = str.upcase + "!"
  yelled
end

def alternating_case(sentence)
  words = sentence.split(" ")

  alt = []

  words.each_with_index do |word, idx|
    idx % 2 == 0 ? (alt << word.upcase) : ( alt << word.downcase )
  end

  alt.join(" ")
  
end