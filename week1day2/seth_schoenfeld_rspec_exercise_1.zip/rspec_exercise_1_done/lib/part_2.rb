def hipsterfy(word)
  vowels = "aeiou"
  reversed_arr = word.split("").reverse
  hipsterfy_arr = []
  
  reversed_arr.each_with_index do |c , i|
    if vowels.include?(c)
        reversed_arr[i] = "" 
        break
    end
  end

  reversed_arr.reverse.join("")
end

def vowel_counts(str)
  vowels = "aeiou"
  hash = Hash.new(0)
  str.each_char do |c|
    if vowels.include?(c.downcase)
      hash[c.downcase] += 1
    end
  end
  hash
end

def caesar_cipher(msg, num)
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    ciphered = ""
    msg.each_char do |c|
        if alphabet.include?(c)
            current_index = alphabet.index(c)
            new_index = current_index + num
            new_char = alphabet[new_index % 26]
            ciphered << new_char
        else
          ciphered << c
        end
    end
    ciphered
end
